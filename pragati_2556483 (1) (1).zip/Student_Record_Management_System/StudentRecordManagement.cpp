#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <limits>
#include <algorithm>
#include <stdexcept>

using namespace std;

const string DATA_FILE = "students.txt";
const int SUBJECT_COUNT = 5;
const string SUBJECTS[SUBJECT_COUNT] = {
    "Mathematics", "Physics", "Chemistry", "English", "Computer Science"
};

// Base class demonstrates inheritance.
class Person {
protected:
    string name;

public:
    Person() : name("") {}
    explicit Person(const string& personName) : name(personName) {}
    virtual ~Person() = default;

    string getName() const { return name; }
};

// Student inherits Person and keeps its data private (encapsulation).
class Student : public Person {
private:
    string rollNumber;
    string course;
    double marks[SUBJECT_COUNT];

public:
    Student() : Person(), rollNumber(""), course("") {
        for (double &mark : marks) mark = 0.0;
    }

    Student(const string& studentName, const string& roll, const string& studentCourse,
            const double studentMarks[SUBJECT_COUNT])
        : Person(studentName), rollNumber(roll), course(studentCourse) {
        for (int i = 0; i < SUBJECT_COUNT; ++i) {
            validateMark(studentMarks[i]);
            marks[i] = studentMarks[i];
        }
        if (name.empty() || rollNumber.empty() || course.empty()) {
            throw invalid_argument("Name, roll number, and course cannot be empty.");
        }
    }

    static void validateMark(double mark) {
        if (mark < 0 || mark > 100) {
            throw invalid_argument("Marks must be between 0 and 100.");
        }
    }

    string getRollNumber() const { return rollNumber; }
    string getCourse() const { return course; }
    double getMark(int index) const {
        if (index < 0 || index >= SUBJECT_COUNT) throw out_of_range("Invalid subject index.");
        return marks[index];
    }

    void setName(const string& value) {
        if (value.empty()) throw invalid_argument("Name cannot be empty.");
        name = value;
    }
    void setCourse(const string& value) {
        if (value.empty()) throw invalid_argument("Course cannot be empty.");
        course = value;
    }
    void setMark(int index, double value) {
        if (index < 0 || index >= SUBJECT_COUNT) throw out_of_range("Invalid subject index.");
        validateMark(value);
        marks[index] = value;
    }

    double totalMarks() const {
        double total = 0;
        for (double mark : marks) total += mark;
        return total;
    }

    double percentage() const {
        return totalMarks() / SUBJECT_COUNT;
    }

    string grade() const {
        double p = percentage();
        if (p >= 90) return "A+";
        if (p >= 80) return "A";
        if (p >= 70) return "B";
        if (p >= 60) return "C";
        if (p >= 50) return "D";
        if (p >= 40) return "E";
        return "F";
    }

    void display() const {
        cout << "\n---------------------------------------------\n";
        cout << "Student Name : " << name << '\n';
        cout << "Roll Number  : " << rollNumber << '\n';
        cout << "Course       : " << course << '\n';
        cout << "Marks:\n";
        for (int i = 0; i < SUBJECT_COUNT; ++i) {
            cout << "  " << left << setw(20) << SUBJECTS[i] << right << fixed
                 << setprecision(2) << marks[i] << "/100\n";
        }
        cout << "Total Marks  : " << fixed << setprecision(2) << totalMarks()
             << " / " << SUBJECT_COUNT * 100 << '\n';
        cout << "Percentage   : " << fixed << setprecision(2) << percentage() << "%\n";
        cout << "Grade        : " << grade() << '\n';
        cout << "---------------------------------------------\n";
    }

    string serialize() const {
        // Use a tab-separated format; input fields are kept free of tabs/newlines.
        ostringstream out;
        out << name << '\t' << rollNumber << '\t' << course;
        for (double mark : marks) out << '\t' << mark;
        return out.str();
    }

    static bool deserialize(const string& line, Student& result) {
        istringstream in(line);
        string fields[3 + SUBJECT_COUNT];
        for (int i = 0; i < 3 + SUBJECT_COUNT; ++i) {
            if (!getline(in, fields[i], '\t')) return false;
        }
        try {
            double loadedMarks[SUBJECT_COUNT];
            for (int i = 0; i < SUBJECT_COUNT; ++i) {
                size_t used = 0;
                loadedMarks[i] = stod(fields[3 + i], &used);
                if (used != fields[3 + i].size()) return false;
                validateMark(loadedMarks[i]);
            }
            result = Student(fields[0], fields[1], fields[2], loadedMarks);
            return true;
        } catch (...) {
            return false;
        }
    }
};

class StudentRecordManagement {
private:
    vector<Student> students;

    static string readNonEmptyLine(const string& prompt) {
        string value;
        while (true) {
            cout << prompt;
            getline(cin, value);
            if (!value.empty() && value.find('\t') == string::npos) return value;
            cout << "Input cannot be empty or contain tab characters. Try again.\n";
        }
    }

    static double readMark(const string& prompt) {
        while (true) {
            cout << prompt;
            string input;
            getline(cin, input);
            try {
                size_t used = 0;
                double mark = stod(input, &used);
                if (used != input.size()) throw invalid_argument("Invalid number");
                Student::validateMark(mark);
                return mark;
            } catch (...) {
                cout << "Invalid marks. Enter a number from 0 to 100.\n";
            }
        }
    }

    int findIndex(const string& roll) const {
        for (int i = 0; i < static_cast<int>(students.size()); ++i) {
            if (students[i].getRollNumber() == roll) return i;
        }
        return -1;
    }

    void saveToFile() const {
        ofstream file(DATA_FILE);
        if (!file) throw runtime_error("Could not open " + DATA_FILE + " for writing.");
        file << fixed << setprecision(2);
        for (const Student& student : students) file << student.serialize() << '\n';
        if (!file) throw runtime_error("An error occurred while saving student records.");
    }

    void loadFromFile() {
        students.clear();
        ifstream file(DATA_FILE);
        if (!file) return; // First run: file will be created when a record is saved.
        string line;
        while (getline(file, line)) {
            if (line.empty()) continue;
            Student student;
            if (Student::deserialize(line, student)) students.push_back(student);
            else cerr << "Warning: skipped an invalid record in " << DATA_FILE << ".\n";
        }
    }

public:
    StudentRecordManagement() { loadFromFile(); }

    void addStudent() {
        cout << "\n--- Add Student ---\n";
        string studentName = readNonEmptyLine("Enter student name: ");
        string roll = readNonEmptyLine("Enter roll number: ");
        if (findIndex(roll) != -1) {
            cout << "A student with this roll number already exists.\n";
            return;
        }
        string course = readNonEmptyLine("Enter course: ");
        double marks[SUBJECT_COUNT];
        for (int i = 0; i < SUBJECT_COUNT; ++i)
            marks[i] = readMark("Enter marks for " + SUBJECTS[i] + " (0-100): ");

        try {
            students.emplace_back(studentName, roll, course, marks);
            saveToFile();
            cout << "Student record added and saved successfully.\n";
        } catch (const exception& e) {
            cout << "Could not add student: " << e.what() << '\n';
        }
    }

    void displayAll() const {
        cout << "\n--- All Student Records ---\n";
        if (students.empty()) {
            cout << "No student records found.\n";
            return;
        }
        for (const Student& student : students) student.display();
        cout << "Total students: " << students.size() << '\n';
    }

    void searchStudent() const {
        cout << "\n--- Search Student ---\n";
        string roll = readNonEmptyLine("Enter roll number to search: ");
        int index = findIndex(roll);
        if (index == -1) cout << "Student record not found.\n";
        else students[index].display();
    }

    void updateStudent() {
        cout << "\n--- Update Student ---\n";
        string roll = readNonEmptyLine("Enter roll number to update: ");
        int index = findIndex(roll);
        if (index == -1) {
            cout << "Student record not found.\n";
            return;
        }

        cout << "1. Update name\n2. Update course\n3. Update subject marks\n";
        cout << "Choose what to update: ";
        string choice;
        getline(cin, choice);

        try {
            if (choice == "1") {
                students[index].setName(readNonEmptyLine("Enter new name: "));
            } else if (choice == "2") {
                students[index].setCourse(readNonEmptyLine("Enter new course: "));
            } else if (choice == "3") {
                for (int i = 0; i < SUBJECT_COUNT; ++i) {
                    cout << i + 1 << ". " << SUBJECTS[i] << '\n';
                }
                cout << "Choose subject number: ";
                string subjectChoice;
                getline(cin, subjectChoice);
                int subject = stoi(subjectChoice);
                if (subject < 1 || subject > SUBJECT_COUNT) {
                    cout << "Invalid subject number.\n";
                    return;
                }
                students[index].setMark(subject - 1,
                    readMark("Enter new marks for " + SUBJECTS[subject - 1] + ": "));
            } else {
                cout << "Invalid choice.\n";
                return;
            }
            saveToFile();
            cout << "Student record updated and saved successfully.\n";
        } catch (const exception& e) {
            cout << "Update failed: " << e.what() << '\n';
        }
    }

    void deleteStudent() {
        cout << "\n--- Delete Student ---\n";
        string roll = readNonEmptyLine("Enter roll number to delete: ");
        int index = findIndex(roll);
        if (index == -1) {
            cout << "Student record not found.\n";
            return;
        }
        students.erase(students.begin() + index);
        try {
            saveToFile();
            cout << "Student record deleted successfully.\n";
        } catch (const exception& e) {
            cout << "Could not save changes: " << e.what() << '\n';
        }
    }

    void run() {
        while (true) {
            cout << "\n=============================================\n";
            cout << "     STUDENT RECORD MANAGEMENT SYSTEM\n";
            cout << "=============================================\n";
            cout << "1. Add student record\n";
            cout << "2. Display all student records\n";
            cout << "3. Search student by roll number\n";
            cout << "4. Update student record\n";
            cout << "5. Delete student record\n";
            cout << "6. Save records and exit\n";
            cout << "Enter your choice: ";

            string choice;
            getline(cin, choice);
            try {
                if (choice == "1") addStudent();
                else if (choice == "2") displayAll();
                else if (choice == "3") searchStudent();
                else if (choice == "4") updateStudent();
                else if (choice == "5") deleteStudent();
                else if (choice == "6") {
                    saveToFile();
                    cout << "Records saved. Thank you for using the system!\n";
                    break;
                } else cout << "Invalid choice. Please select 1-6.\n";
            } catch (const exception& e) {
                cout << "Error: " << e.what() << '\n';
            }
        }
    }
};

int main() {
    try {
        StudentRecordManagement system;
        system.run();
    } catch (const exception& e) {
        cerr << "Fatal error: " << e.what() << '\n';
        return 1;
    }
    return 0;
}
