# Student Record Management System (C++)

## Project overview
A console-based Student Record Management System implemented in C++ using object-oriented programming. It stores student details and marks in a local text file (`students.txt`).

## Features
- Add student details: name, roll number, course.
- Record marks in five subjects (0–100 each).
- Automatically calculate total marks, percentage, and grade.
- Display all student records.
- Search by roll number.
- Update name, course, or a subject's marks.
- Delete a student record.
- Validate required fields, duplicate roll numbers, and marks.
- Save records to `students.txt` so data remains available after restarting.

## OOPS concepts used
- **Class and objects:** `Person`, `Student`, and `StudentRecordManagement`.
- **Encapsulation:** Student data is private and accessed through methods.
- **Constructors:** Default and parameterized constructors initialize objects.
- **Inheritance:** `Student` publicly inherits from `Person`.
- **Exception handling:** `try/catch` and exceptions validate data and report file errors.
- **File handling:** `ifstream` loads records and `ofstream` saves them.

## Grade criteria
| Percentage | Grade |
|---|---|
| 90–100 | A+ |
| 80–89.99 | A |
| 70–79.99 | B |
| 60–69.99 | C |
| 50–59.99 | D |
| 40–49.99 | E |
| Below 40 | F |

## Files
- `StudentRecordManagement.cpp` — complete source code.
- `students.txt` — data file used by the application (starts empty).
- `sample_output.txt` — example output for demonstration.
- `CMakeLists.txt` — optional CMake build file.

## Compile and run

### Windows (g++ / MinGW)
Open Command Prompt in this folder:
```bash
g++ -std=c++17 -Wall -Wextra -o StudentRecordManagement.exe StudentRecordManagement.cpp
StudentRecordManagement.exe
```

### Linux / macOS
```bash
g++ -std=c++17 -Wall -Wextra -o StudentRecordManagement StudentRecordManagement.cpp
./StudentRecordManagement
```

### Using CMake
```bash
cmake -S . -B build
cmake --build build
```

Keep `students.txt` in the same working directory as the executable. The program creates it automatically when saving records.

## Demonstration
Choose option `1`, enter a student's name, unique roll number, course, and five marks. Choose option `2` to view the calculated total, percentage, and grade. Choose option `6` to save and exit. Run again to verify that the record was saved.
